/*********************************************************************/
/* Poker Project, for EECS 22L, Spring 2024                   		 */
/* structures.h: Structure Definitions							     */
/*********************************************************************/



// this file may not be necessary